In case we forget to mention fixed issues when commit the change, edit and commit this file with appropriate message so that issues can be linked to builds

issue #34
issue #48 
issue #55 
issue #102 
issue #5 
issue #99 
issue #132 
issue #148 
issue #172
issue #173
issue #191 
issue #212 
issue #223 
issue #255