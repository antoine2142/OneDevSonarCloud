package io.onedev.server.model;

public class ModelLocator {

}
