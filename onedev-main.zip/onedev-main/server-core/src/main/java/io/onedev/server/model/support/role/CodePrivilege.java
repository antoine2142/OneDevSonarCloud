package io.onedev.server.model.support.role;

public enum CodePrivilege {NONE, READ, WRITE}