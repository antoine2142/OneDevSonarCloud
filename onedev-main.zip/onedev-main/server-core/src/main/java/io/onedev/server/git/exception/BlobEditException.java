package io.onedev.server.git.exception;

public class BlobEditException extends GitException {

	private static final long serialVersionUID = 1L;

	public BlobEditException(String message) {
		super(message);
	}

}
