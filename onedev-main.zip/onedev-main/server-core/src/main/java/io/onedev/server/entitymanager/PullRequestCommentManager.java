package io.onedev.server.entitymanager;

import io.onedev.server.model.PullRequestComment;
import io.onedev.server.persistence.dao.EntityManager;

public interface PullRequestCommentManager extends EntityManager<PullRequestComment> {

}
