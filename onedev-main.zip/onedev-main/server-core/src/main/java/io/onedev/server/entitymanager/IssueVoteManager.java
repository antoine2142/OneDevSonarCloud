package io.onedev.server.entitymanager;

import io.onedev.server.model.IssueVote;
import io.onedev.server.persistence.dao.EntityManager;

public interface IssueVoteManager extends EntityManager<IssueVote> {

}
